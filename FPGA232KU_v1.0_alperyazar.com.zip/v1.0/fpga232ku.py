#--Geli�tirici: Alper Yazar (www.alperyazar.com)
#-- Iletisim: posta[at]alperyazar[nokta]com
#-- Versiyon: 1.0
#-- Lisans: CC BY-NC-SA 3.0 (http://creativecommons.org/licenses/by-nc-sa/3.0/) (Belirtilen lisans ko�ullar�na uyulmas�n� rica ediyorum.)
#-- URL: http://www.alperyazar.com/?p=93
#-- Tarih: Agustos 2011
#----------------------------------------------------------------------------------------------------------------------------------------
#-- FPGA232KU hakk�nda bilgi edinmek i�in l�tfen yukar�daki URL'yi ziyaret ediniz. Lisans ko�ullar�na uyuldu�u takdirde de�i�iklik yap�labilir.
#-- De�i�iklik yapmadan �nce URL ile yukar�da belirtilen adresten bilgi edinmeniz faydal� olabilir.
#-- Soru sormak ve g�r�� bildirmek i�in de yine ayn� adresi kullanabilirsiniz
#----------------------------------------------------------------------------------------------------------------------------------------

from Tkinter import *
from tkFileDialog import askopenfilename, asksaveasfilename
from tkMessageBox import *
import codecs
import webbrowser
from functools import partial

def baglantiya_git(url, event=None):
    webbrowser.open(url)

def hyperlink(text, url, row, column):
    link = Label(text=text, foreground="blue", cursor="hand2")
    link.bind("<1>", partial(baglantiya_git, url))
    link.grid(row=row, column=column)
   
    return link

def hedef_dosya_yeri_sor():
	options = {}
	options['filetypes'] = [('VHDL Dosyasi', '.vhd')]
	hedef_dosya_giris.insert(0, asksaveasfilename(**options))

def kaynak_dosya_yeri_sor():
	options = {}
	options['filetypes'] = [('Sablon Dosyalari', '.template'), ('Tum Dosyalar', '.*')]
	kaynak_dosya_giris.insert(0, askopenfilename(**options))

def dosyayi_olustur():
	try:
		baudrate = int(baud_rate_giris.get())
	except ValueError:
		showerror("Hata!","Baud Rate kutusuna lutfen bir tam sayi giriniz.")
		return;
	except:
		showerror("Hata!","Program Baud Rate kutusundaki deger ile ilgili bilinmeyen bir hata ile karsilasti.");
		return;
		
	if (baudrate <= 0):
		showerror("Hata!","Baud Rate degeri pozitif olmalidir.");
		return;
		
	try:
		saat_frekansi = int(saat_frekansi_giris.get())
	except ValueError:
		showerror("Hata!","Saat Frekansi kutusuna lutfen bir tam sayi giriniz.")
		return;
	except:
		showerror("Hata!","Program Saat Frekansi kutusundaki deger ile ilgili bilinmeyen bir hata ile karsilasti.");
		return;
		
	if (saat_frekansi <= 0):
		showerror("Hata!","Saat Frekansi degeri pozitif olmalidir.");
		return;
		
	if ( (saat_frekansi * 1000000 / baudrate) < 10 ):
		showerror ("Hata!","Saat Frekansi / Baud Rate degeri cok dusuk. Bu frekans ile bu hizda duzgun calisma saglanamayabilir.");
		return;
	try:
		kaynak_dosya = codecs.open(kaynak_dosya_giris.get(),"r","utf-8")
		okunan_dosya = kaynak_dosya.read()
		kaynak_dosya.close()
	except IOError:
		showerror("Hata!","Kaynak Dosya acilamadi.")
		return;
	except UnicodeDecodeError:
		showerror("Hata!","Program Kaynak Dosya'nin UTF-8 kodlandigindan emin olun.");
		return;
	try:
		hedef_dosya = codecs.open(hedef_dosya_giris.get(),"w","utf-8")
	except IOError:
		showerror("Hata!","Hedef Dosya acilamadi.")
		return;
	except UnicodeDecodeError:
		showerror("Hata!","Program Hedef Dosya'nin UTF-8 kodlandigindan emin olun.");
		return;
	
	beklenecek_clock_sayisi = int(round(saat_frekansi * 1000000.0 / baudrate))
	##
	beklenecek_clock_sayisi_BIN = bin(beklenecek_clock_sayisi)
	beklenecek_clock_sayisi_BIN = beklenecek_clock_sayisi_BIN [2: len(beklenecek_clock_sayisi_BIN)]
	##
	bekleme_vektoru_ust_bit_indeksi = len(beklenecek_clock_sayisi_BIN) - 1
	##
	rx_baslatilacak_deger_BIN = "0"+bin(beklenecek_clock_sayisi >> 1)[2: len(bin(beklenecek_clock_sayisi >> 1))]
	
	
	okunan_dosya=okunan_dosya.replace("##$bekleme_vektoru_ust_bit_indeksi$##",str(bekleme_vektoru_ust_bit_indeksi))
	okunan_dosya=okunan_dosya.replace("##$bekleme_vektoru_siniri$##",beklenecek_clock_sayisi_BIN)
	okunan_dosya=okunan_dosya.replace("##$rx_bekleme_vektoru_ilk_deger$##",rx_baslatilacak_deger_BIN)
	okunan_dosya=okunan_dosya.replace("##$clk_frekansi$##",str(saat_frekansi))
	okunan_dosya=okunan_dosya.replace("##$baud_rate_degeri$##",str(baudrate))
	
	
	hedef_dosya.write(okunan_dosya)
	hedef_dosya.close()
	showinfo("Basarili","%s dosyasinda kod olusturuldu."%hedef_dosya_giris.get())

pencere = Tk()
pencere.resizable(width=FALSE, height=FALSE)
pencere.title("FPGA232KU | alperyazar.com")
pencere.iconbitmap("ay.ico")
pencere.geometry("280x150+300+300")

kaynak_dosya = Label(text="Kaynak Dosya")
kaynak_dosya.grid(row=0, column=0, sticky=W)

kaynak_dosya_giris = Entry()
kaynak_dosya_giris.grid(row=0, column=1)

kaynak_dosya_ara = Button(text="Bul", command=kaynak_dosya_yeri_sor)
kaynak_dosya_ara.grid(row=0, column=2)

hedef_dosya = Label(text="Hedef Dosya")
hedef_dosya.grid(row=1, column=0, sticky=W)

hedef_dosya_giris = Entry()
hedef_dosya_giris.grid(row=1, column=1)

hedef_dosya_ara = Button(text="Bul", command=hedef_dosya_yeri_sor)
hedef_dosya_ara.grid(row=1, column=2)

baud_rate = Label(text="Baud Rate")
baud_rate.grid(row=2, column=0, sticky=W)

baud_rate_giris = Entry()
baud_rate_giris.grid(row=2, column=1)

saat_frekansi = Label(text="Saat Frekansi (MHz)")
saat_frekansi.grid(row=3, column=0, sticky=W)

saat_frekansi_giris = Entry()
saat_frekansi_giris.grid(row=3, column=1)

bilgier_gelistirici_label = Label(text="Gelistirici:")
bilgier_gelistirici_label.grid(row=4, column=0, stick=W)

bilgier_gelistirici_link = hyperlink("Alper Yazar", "http://www.alperyazar.com", 4, 1)

bilgiler_versiyon_label = Label(text="Versiyon:")
bilgiler_versiyon_label.grid(row=5, column=0, sticky=W)

bilgier_versiyon_link = hyperlink("1.0 (Hakkinda - Yardim)", "http://www.alperyazar.com/?p=93", 5, 1)

bilgiler_lisans_label = Label(text="Lisans")
bilgiler_lisans_label.grid(row=6, column=0, sticky=W)

bilgiler_lisans_link = hyperlink("CC BY-NC-SA 3.0", "http://creativecommons.org/licenses/by-nc-sa/3.0/", 6, 1)

olustur_dugmesi = Button(text="Olustur", command=dosyayi_olustur)
olustur_dugmesi.grid(row=2, column=2)

cikis_dugmesi = Button(text="Cikis", command=pencere.quit)
cikis_dugmesi.grid(row=3, column=2)

mainloop()